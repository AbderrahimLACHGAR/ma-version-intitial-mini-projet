package ma.inventivit.repository;

public @interface Service {
}
