package ma.inventivit;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "cases")

public class Case {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int caseId;

    @Temporal(TemporalType.DATE)
    @Column(name = "CreationDate")
    Date creationDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "lastUpdateDate")
    Date lastUpdateDate;

    @Column(name = "title")
    private String title;

    @Column(name = "description")
    private String description;

    public Case() {

    }

    public Case(int caseId, Date creationDate, Date lastUpdateDate, String title, String description) {
        this.caseId = caseId;
        this.creationDate = creationDate;
        this.lastUpdateDate = lastUpdateDate;
        this.title = title;
        this.description = description;
    }

    public int getCaseId() {
        return caseId;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public void setCaseId(int caseId) {
        this.caseId = caseId;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Case{" +
                "caseId=" + caseId +
                ", creationDate=" + creationDate +
                ", lastUpdateDate=" + lastUpdateDate +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}