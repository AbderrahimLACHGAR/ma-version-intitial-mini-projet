package ma.inventivit;

public @interface SpringBootTest {
}
