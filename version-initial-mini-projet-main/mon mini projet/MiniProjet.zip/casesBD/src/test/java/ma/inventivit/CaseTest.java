package ma.inventivit;

import org.junit.jupiter.api.Test;

class CaseTest {

    @Test
    void getCaseId() {
     }

    @Test
    void getTitle() {
    }
}