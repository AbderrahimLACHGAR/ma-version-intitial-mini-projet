package ma.inventivit.repository;

public @interface Autowired {
}
